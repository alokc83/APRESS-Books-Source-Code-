//
//  Sample_04AppDelegate_iPad.m
//  Sample 04
//
//  Created by Lucas Jordan on 4/6/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Sample_04AppDelegate_iPad.h"

@implementation Sample_04AppDelegate_iPad

- (void)dealloc
{
	[super dealloc];
}

@end
