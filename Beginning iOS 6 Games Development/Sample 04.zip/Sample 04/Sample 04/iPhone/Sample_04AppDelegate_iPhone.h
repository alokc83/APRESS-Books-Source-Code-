//
//  Sample_04AppDelegate_iPhone.h
//  Sample 04
//
//  Created by Lucas Jordan on 4/6/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Sample_04AppDelegate.h"

@interface Sample_04AppDelegate_iPhone : Sample_04AppDelegate {
    
}

@end
